export default function LoadMore() {
    return (
        <>
            <div className="d-flex justify-content-center align-items-center mt-5">
            <button className="btn btn-outline-primary px-5 rounded-0" type="button">LOAD MORE</button>
        </div>
        </>
    )
}