export default function Header() {
    return (
        <>
        <h2 className="mt-5">Restaurants</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure necessitatibus delectus maxime perferendis fuga possimus expedita accusantium iusto.</p>
        </>
    )
}